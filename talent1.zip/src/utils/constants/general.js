export const BASE_URL =
   'http://peaksoftlmsbb4-env.eba-i4eppj78.eu-west-2.elasticbeanstalk.com'
