import * as React from 'react'
import Radio from '@mui/material/Radio'

export const RadioButton = (props) => {
   return <Radio {...props} />
}
